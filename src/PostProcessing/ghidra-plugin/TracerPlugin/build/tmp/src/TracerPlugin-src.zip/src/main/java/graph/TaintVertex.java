package graph;

import ghidra.graph.viewer.vertex.DockingVisualVertex;

public class TaintVertex extends DockingVisualVertex {

	public TaintVertex(String name) {
		super(name);
	}
}
