package program;

import java.util.ArrayList;

import db.TaintEvent;
import docking.Tool;
import ghidra.app.services.ProgramManager;
import ghidra.program.model.listing.CodeUnit;
import ghidra.program.model.listing.Program;

public class ProgramOperator {
	private Program currentProgram;
	private Tool tool;
	
	public ProgramOperator(Tool tool) {
		this.tool = tool;
		ProgramManager programManager = this.tool.getService(ProgramManager.class);
		if (programManager == null) {
            System.err.println("Could not access ProgramManager service");
        }
		this.currentProgram = programManager.getCurrentProgram();
		if (currentProgram == null) {
            System.err.println("Could not open ghidra program");
        }
	}
	
	public void taintGhidraInstructionsWithTaintEvents(ArrayList<TaintEvent> eventList) {
		if(this.tool == null || this.currentProgram == null) {
			throw new IllegalStateException("Cannot operate with the program, it was not correctly initialized");
		}
		
		long baseOffset = currentProgram.getImageBase().getOffset();
		for(CodeUnit codeUnit : currentProgram.getListing().getCodeUnits(true)) {
			System.out.println(codeUnit.getAddress().getOffset());
			
		}
	}
}
